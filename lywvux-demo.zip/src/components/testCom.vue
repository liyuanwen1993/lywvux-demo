<template>
    <div>
        <div>111{{testOne}}</div>
    </div>
</template>
<script>
export default {
    props: {
        testOne:{
            type:[String,Number],
            default:'默认名称'
        }
    },
    data() {
        return {
            /*testOne:this[test-one]?'test-one':""*/
        }
    },
    computed: {

    }
}
</script>
<style>
.vux-demo {
    text-align: center;
}

.logo {
    width: 100px;
    height: 100px
}
</style>
