import Vue from 'vue'
let Util = new Vue({})
export default Util;